<?php
session_start();
include 'Config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = htmlspecialchars($_POST['username']);
    $password = htmlspecialchars($_POST['pswd']);

    $stmt = $conn->prepare("SELECT * FROM user_ WHERE username = ? ");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['pswd'])) {
            $_SESSION['username'] = $username;
            echo "<script>alert('Successfully logged in!')</script>";
            header("Location: dashboard.php");
            exit();
        } else {
            echo "<script>alert('Wrong Credentials!')</script>";
        }
    } else {
        echo "<script>alert('User not found!')</script>";
    }
} 
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <title>Login</title>
</head>

<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-4 text-center">
                <form action="" method="post">
                    <h2 class="h2 mb-3 mt-5">Login Here</h2>
                    <div class="form-floating mb-3">
                        <input type="text" class="form-control" placeholder="Enter name" name="username" id="username">
                        <label for="username">username</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="password" class="form-control" name="pswd" id="pswd" placeholder="Enter name">
                        <label for="pswd">Password</label>
                    </div>
                    <input type="submit" value="Login" class="btn rounded-pill btn-success">
                    <button type="button" class="btn rounded-pill btn-success"><a href="register.php" class="link-underline-success text-white">SignUp</a></button>
                </form>
            </div>
        </div>
</body>

</html>