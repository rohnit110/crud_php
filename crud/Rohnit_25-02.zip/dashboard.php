<html>

<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://getbootstrap.com/docs/5.3/assets/css/docs.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3-/dist/js/bootstrap.bundle.min.js"></script>

</head>

<body>
    <form class="mt-5" method="get" action="">
        <nav class="navbar ms-3 me-3 navbar-expand-sm">
            <div class="container">
                <div class="d-flex col-10 justify-content-between">
                    <div class="col-3 input-group">
                        <input type="search" class="form-control-sm me-1" name="search" value="<?php if (isset($_GET['search'])) {
                                                                                                    echo $_GET['search'];
                                                                                                } ?>" placeholder="Search here">
                        <input type="submit" class="btn btn-primary me-2" value="Search">
                    </div>
                    <div class="col-2 ms-5">
                        <button type="button" class="btn btn-success"><a href="add_data.php" class="link-underline-success text-white ">Add</a></button>
                        <button type="button" class="btn btn-danger"><a href="logout.php" class="link-underline-danger text-white">Logout</a></button>
                    </div>
                </div>
            </div>
        </nav>
    </form>
    <h1 class="h2 text-center">Dashboard</h1>


    <?php

    $servername = 'localhost';
    $username = 'root';
    $password = '';
    $dbname = 'myproduct';
    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }


    $result_per_page = 5;
    if (isset($_GET['result_per_page']) && is_numeric($_GET['result_per_page'])) {
        $result_per_page = $_GET['result_per_page'];
    }
    if (!isset($_GET["page"])) {
        $page = 1;
    } else {
        $page = $_GET["page"];
    }
    $start_from = ($page - 1) * $result_per_page;

    // $sql1 = "SELECT * FROM products LIMIT $start_from, $result_per_page";
    // $result = $conn->query($sql1);
    //sort
    $orderBy = isset($_GET['orderBy']) ? $_GET['orderBy'] : 'id';
    $order = isset($_GET['order']) ? $_GET['order'] : 'ASC';

    $sql3 = "SELECT * FROM products ORDER BY $orderBy $order LIMIT $start_from, $result_per_page";
    $result = $conn->query($sql3);
    ?>
    <div class='container'>
        <table class='table text-center table-dark text-light mb-0'>
            <th class="col-2"><a class="text-light link-underline-dark" href="?orderBy=product_id&order=<?= ($orderBy === 'product_id' && $order === 'ASC') ? 'DESC' : 'ASC'; ?>">Product Id</a></th>
            <th class="col-2"><a class="text-light link-underline-dark" href="?orderBy=product_name&order=<?= ($orderBy === 'product_name' && $order === 'ASC') ? 'DESC' : 'ASC'; ?>">Product</a></th>
            <th class="col-2"><a class="text-light link-underline-dark" href="?orderBy=product_description&order=<?= ($orderBy === 'product_description' && $order === 'ASC') ? 'DESC' : 'ASC'; ?>">Description</a></th>
            <th class="col-2"><a class="text-light link-underline-dark" href="?orderBy=price&order=<?= ($orderBy === 'price' && $order === 'ASC') ? 'DESC' : 'ASC'; ?>">Price</a></th>
            <th class="col-4">Image</th>
        </table>
    </div>
    <?php
    error_reporting(E_ALL);
    ini_set('display_errors', 1);

    if (!isset($_GET["search"])) {
        echo "<div class='container'>";
        echo "<table class='table text-center table-striped'>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr class='container'>";
            echo "<td class='col-2'> {$row['product_id']}</td>";
            echo "<td class='col-2'>  {$row['product_name']}</td>";
            echo "<td class='col-2'>  {$row['product_description']}</td>";
            echo "<td class='col-2'>  {$row['price']}</td>"; ?>
            <td class='col-4'> <img src="Config/<?php echo $row['product_image']; ?>" alt="Product Image" style="width: 100px;"></td>
            <?php echo "</tr>";
        }
        echo "</table>";
        echo "</div>";
    } else {
        $searchTerm = $_GET['search'];
        $sql1 = "SELECT * FROM products WHERE CONCAT(product_name, product_description, price,product_id) LIKE '%$searchTerm%'";
        $filterdata = mysqli_query($conn, $sql1);
        echo "<div class='container'>";
        echo "<table class='table text-center table-striped'>";
        if (mysqli_num_rows($filterdata) > 0) {
            foreach ($filterdata as $row1) {
                echo "<tr class='container row'>";
                echo "<td class='col-2'>  {$row1['product_id']}</td>";
                echo "<td class='col-2'> {$row1['product_name']}</td>";
                echo "<td class='col-2'>  {$row1['product_description']}</td>";
                echo "<td class='col-2'>  {$row1['price']}</td>"; ?>
                <td class='col-4'> <img src="Config/<?php echo $row1['product_image']; ?>" alt="Product Image" style="width: 100px;"></td>
                </td>
        <?php
                echo "</tr>";
            }
        }
        echo "</table>";
        echo "</div>";
    }

    if (isset($_GET["search"]) == 0) {
        //pagination
        $sql1 = "SELECT COUNT(id) AS total FROM products";
        $result = $conn->query($sql1);
        $row = $result->fetch_assoc();
        $total_pages = ceil($row['total'] / $result_per_page);

        echo "<nav class='container'>";
        echo "<ul class='pagination '>";
        echo " <div class='d-flex flex-grow-1'>";

        if ($page > 1) {
            echo "<li class='page-item'><a class='page-link' href='index1.php?page=" . ($page - 1) . "&result_per_page=$result_per_page&orderBy=$orderBy&order=$order'><</a></li>";
        }

        for ($i = 1; $i <= $total_pages; $i++) {
            echo "<li class='page-item " . ($page == $i ? 'active' : '') . "'><a class='page-link' href='index1.php?page=$i&result_per_page=$result_per_page&orderBy=$orderBy&order=$order'>$i</a></li>";
        }

        if ($page < $total_pages) {
            echo "<li class='page-item'><a class='page-link' href='index1.php?page=" . ($page + 1) . "&result_per_page=$result_per_page&orderBy=$orderBy&order=$order'>></a></li>";
        }
        echo "</div>";
        ?> <div class=" border border-primary bg-primary ms-2 text-light">
            <label for="page" class="form-label m-auto">Page</label>
            <select class="form-select-sm" class="" id="page" onchange="viewDataPerPage(this)">
                <option value="5" <?php if ($result_per_page == 5)
                                        echo "selected"; ?>>5</option>
                <option value="10" <?php if ($result_per_page == 10)
                                        echo "selected"; ?>>10</option>
                <option value="15" <?php if ($result_per_page == 15)
                                        echo "selected"; ?>>15</option>
                <option value="20" <?php if ($result_per_page == 20)
                                        echo "selected"; ?>>20</option>
            </select>
        </div>
        <script>
            function viewDataPerPage(dpp) {
                var value = dpp.value;
                window.location.href = "index1.php?result_per_page=" + value;
            }
        </script><?php
                    echo "</ul>";
                    echo "</nav>";
                }
                    ?>


    <?php
    $conn->commit();

    ?>
</body>

</html>