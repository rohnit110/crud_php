<?php

include 'Config/database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = htmlspecialchars($_POST['username']);
    $email = htmlspecialchars($_POST['email']);
    $number = htmlspecialchars($_POST['mo_num']);
    $password = htmlspecialchars($_POST['pswd']);

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Use prepared statement to prevent SQL injection
    $stmt = $conn->prepare("INSERT INTO user_ (username, emailId, mo_num, pswd) VALUES (?, ?, ?, ?)");

    $stmt->bind_param("ssss", $username, $email, $number, $hashed_password);

    if ($stmt->execute()) {
        echo "<script>alert('Successfully Signed Up!')</script>";
        header("location: index.php");
    } else {
        echo "<script>alert('Registration failed!')</script>";
    }

    $stmt->close();
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ecommerce</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</head>

<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-4 text-center">
                <form action="" method="post">
                    <h2 class="h2 mb-3 mt-5">Registration</h2>
                    <div class="form-floating mb-3">
                        <input type="text" class="form-control" placeholder="Enter name" name="username" id="username">
                        <label for="username">username</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="email" class="form-control" name="email" placeholder="Enter name" id="email">
                        <label for="email">EmailId</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="tel" class="form-control" name="mo_num" id="mo_num" placeholder="Enter Mobile number">
                        <label for="mo_num">Mobile No.</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="password" class="form-control" name="pswd" id="pswd" placeholder="Enter name">
                        <label for="pswd">Password</label>
                    </div>
                    <input type="submit" value="Signup" class="btn rounded-pill btn-success">
                    <button type="button" class="btn rounded-pill btn-success"><a href="index.php" class="link-underline-success text-white">Login</a></button>
                </form>
            </div>

        </div>
    </div>
</body>

</html>