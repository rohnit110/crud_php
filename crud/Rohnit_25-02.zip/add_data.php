<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insert Data</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

</head>

<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-4 text-center">
                <form action="" method="post" enctype="multipart/form-data">
                    <h2 class="h2 mb-3">Add Data</h2>
                    <div class="form-floating text-align-center mb-3">
                        <input type="text" class="form-control" name="id" id="id" placeholder="id" required>
                        <label for="id">Product_id</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="text" class="form-control" name="name" id="name" placeholder="Product" required>
                        <label for="name">Product</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="text" class="form-control" name="description" id="description" placeholder="id">
                        <label for="description">Description</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="number" class="form-control" name="price" id="price" placeholder="id" required>
                        <label for="price">Price</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="file" class="form-control" name="product_image" id="product_image">
                        <label for="product_image">Image</label>
                    </div>
                    <input type="submit" class="btn btn-rounded-pill btn-success" value="Add" name="submit">
                </form>
            </div>
        </div>
</body>

</html>

<?php
include "Config/database.php";

if (isset($_POST['submit'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];

    if ($_FILES["product_image"]["error"] === 4) {
        echo "<script>alert('Image doesn\'t exist');</script>";
    }

    $filename = $_FILES['product_image']['name'];
    $filesize = $_FILES['product_image']['size'];
    $tmpname = $_FILES['product_image']['tmp_name'];
    $folder = "Config/";

    $Extension = ['jpg', 'jpeg', 'png'];
    $image = explode('.', $filename);
    $image = strtolower(end($image));

    if (!in_array($image, $Extension)) {
        echo "<script>alert('Invalid Image Extension');</script>";
    } elseif ($filesize > 100000000) {
        echo "<script>alert('Image size is too large');</script>";
    } else {
        $newimagename = uniqid();
        $newimagename .= '.' . $image;

        move_uploaded_file($tmpname, 'Config/' . $newimagename);

        $query = "INSERT INTO products(product_id, product_name, product_description, price, product_image) 
                  VALUES('$id', '$name', '$description', '$price', '$newimagename')";
        mysqli_query($conn, $query);

        echo "<script>alert('Successfully added');</script>";
    }
}
?>
