<?php
session_start();
include 'Config/database.php';
session_unset();
session_destroy();
header("location: index.php");
